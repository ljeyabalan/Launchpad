/* global app, client, utils */
app.initialized().then(
    function(_client) {
      //If successful, register the app activated and deactivated event callback.
      window.client = _client;
    },
    function(error) {
      //If unsuccessful
      console.log(error);
    }
  );
  
  
function getRoles() {
    var url = utils.get('freshdeskDomain') + '/api/v2/roles';
    var headers = {
        "Authorization": "Basic " + btoa(utils.get('freshdeskApikey') + ':x'),
        "Content-Type": "application/json"
    };
    var options = {
        headers: headers,
    };
    console.log('url = ', url)
    console.log('options = ', options)
    console.log('freshdeskDomain', utils.get('freshdeskDomain'))
  console.log('freshdeskApikey', utils.get('freshdeskApikey'))
  let roles = [];
    var p = new Promise(function(resolve, reject) {
      client.request.get(url, options).then(
        function(data) {

        //utils.set(‘multiselect’, {values: [Travelling, Swimming, Reading books], label: ‘Hobbies’});
        console.log('data == ', data)
            console.log('parse data ==== ', JSON.parse(data.response))
            JSON.parse(data.response).forEach(role => {
                console.log('role.name == ', role.name)
                console.log('role.id == ', role.id)
                roles.push(`${role.name} : ${role.id}`);
            });
          // Upon success
          resolve();
        },
        function(error) {
            console.log('error = =', error)
          // Upon failure - send an appropriate validation error message
          reject("The account credentials are wrong.");
        }
      );
    });
    console.log('p = ', p)
    utils.set('roles', {values: roles});
    utils.set('showRoles', {value: false});
    return p;
}