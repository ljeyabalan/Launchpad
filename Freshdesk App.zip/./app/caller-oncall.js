function newticketCreate(contacphone) {
    var din = $('#w3mission').val();

    console.log('getCallSid() ====', getCallSid())
console.log('getCallDirection == ', getCallDirection())
    console.log('din', din)
    console.log('din.contact==', JSON.parse(din).contact[0])
    //console.log('din', JSON.parse(din).contact[0].phone)
    let contactId = JSON.parse(din).contact[0] == undefined ? 0 : JSON.parse(din).contact[0].id;
    console.log('contactId = ' , contactId)
    console.log('contactId  check', contactId !==0)
    
console.log('typeof(contacphone)===', typeof(contacphone))

var contactphone = JSON.parse(din).contact[0] == undefined ? JSON.parse(din).phone : JSON.parse(din).contact[0].phone;

console.log('contactphone===', contactphone)
console.log('contactphone===', typeof(contactphone))
    var contactname = JSON.parse(din).contact[0] == undefined ? JSON.parse(din).name : JSON.parse(din).contact[0].name;
   console.log('contactname in on-call', contactname)
    

    $(".createTickets").hide();
    $(".callerOnCall").show();
    $(".callerDetails").hide();
    
    $(".recentTickets").hide();
    $("#AllTickets").hide();
    $('#callHistoryList').hide();

    if(JSON.parse(din).contact[0] != undefined && contactId !== 0) {
    var contactDeepLinkIcon = `<div class="col-5 text-right" style="padding-left: 95px;">
   <button style="background-color:#1f3f58;color: #f9f9f9; min-width: 135px; border-radius: 50px;" id="nav-link active rounded-pro-sm" data-num="'+{"name":"name1"}+'" 
             onClick="contactDeepLink('${JSON.parse(din).contact[0].id}')" class="pull-right btn call-atten w100">View Contact</button>
    </div>`
   }

     var replyHtmlObj ='';
   replyHtmlObj = `<div class="on-call-sec sec-wdth bx-shadow bdr-rds10 bg-white min-hgt500">
   <div class="call-head bg-dark-blue pt-xl-2 pl-xl-3 pr-xl-3 pb-xl-2">
      <div class="row align-items-center">
         <div class="col-2 pdrgt0">
            <div class="rounded-pro-sm">
               <span>${contactname.substring(0,1)}</span>
            </div>
         </div>
         <div class="col-5 pl-xl-1 person-details">
            <p>${contactname}</p>
            <span>${contactphone}</span>	
         </div>`
         
        if(JSON.parse(din).contact[0] == undefined) { 
         replyHtmlObj += ``
        }
        else{
         replyHtmlObj += contactDeepLinkIcon
        }
         

        replyHtmlObj += `</div>
   </div>
   <div class="content-body">
      <div class="col-12 pad0">
         <ul class="head-tabs-sec nav nav-tabs bg-white pt-xl-2 pl-xl-3 pr-xl-3 nav-tab-wrapper" id="myTab" role="tablist">
            <li class="nav-item">
               <a class="nav-link nav-tab nav-tab-active active" id="call-notes" data-toggle="tab" href="#" role="tab" aria-controls="home" aria-selected="true" onClick="clickCallNotes()">Call Notes</a>
            </li>
            <li class="nav-item">
               <a class="nav-link nav-tab" id="ticket-history" data-toggle="tab" href="#" role="tab" aria-controls="home" aria-selected="true" onClick="clickRecentTicket()">Ticket history</a>  
            </li>
         </ul>
         <div style="padding-top: 0px;" id="ticketss" class="recentTickets"></div>
         <div>
         <div class="tab-content active pt-xl-3 pl-xl-3 pr-xl-3 pb-xl-3" id="myTabContent">
            <div class="tab-pane fade show tab-content active" id="tab-1" role="tabpanel" aria-labelledby="head-tabs">
               <form class="call-notes-frm">`;
               console.log('contactId ==== ' , contactId)
               if(contactId === 0){
                replyHtmlObj += `<div class="form-group">
                     <label>Caller Name</label>
                     <input class="form-control" type="text" placeholder="" name="callfrom"  id="contactname" >
                     </div>`;
               }else{
                     replyHtmlObj +=`<textarea id="contactname" style="display: none;">${contactname}</textarea>`;

               }
                
               if(JSON.parse(din).contact[0] != undefined) {
                  replyHtmlObj += `<textarea id="contactId" style="display: none;">${JSON.parse(din).contact[0].id}</textarea>`;
               }
           replyHtmlObj += ` <div class="form-group">
                     <label>Call Notes</label>
                     <textarea class="form-control" rows="3" cols="50" placeholder="" name="callfrom"  id="description" style="height: 200px;"></textarea>
                     </div>
          
          
               </form>
            </div>
            <div class="tab-pane fade tab-content" id="tab-2" role="tabpanel" aria-labelledby="head-tabs">
             <form class="call-notes-frm">
                  <div class="form-group">
                     <label>Call Notes</label>

                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="call-action-buttons pt-xl-4 pl-xl-4 pr-xl-4 pb-xl-4" id="createTicketNotes">
         <div class="col-12">
            <ul class="nav nav-pills pb-xl-3">
               <li class="nav-item">
               
                  <button style="background-color:#1f3f58;color: #f9f9f9; min-width: 160px; border-radius: 40px; margin-left: 80px;" id="logcreate" data-num="'+{"name":"name1"}+'" onClick="createTicket('${contactphone}')" class="pull-right btn call-atten w100 ticketCreateButton">Create Ticket</button>
               </li>
            </ul>
         </div>
      </div>
   </div>
   </div>`
;
replyHtmlObj += footerHTML;

$(".callerDetailsPage").empty();
$(".callerDetailsPage").append(replyHtmlObj);
    $(".callerDetailsPage").show(); 
 //});
}
 

/** create new Ticket **/
function createTicket(phone) {
   $(".ticketCreateButton").prop('disabled', true); 
   
let callSid = getCallSid();
console.log('callSid.val()===============', callSid)
   let reqObject = {
      exotelSid: callSid
   }
   var headers = {
      "Content-Type": "application/json"
   };
   var options = {
      headers: headers,
      body: JSON.stringify(reqObject)
   };
   var url = localStorage.getItem('endpoint_url') + "/getCallsDetails";

   client.request.get(url, options)
      .then((data) => {
         console.log('getCallDetails resss= ', JSON.parse(data.response))
         console.log('getCallDetails resss= ', JSON.parse(data.response).duration)
         console.log('getCallDetails resss= ', JSON.parse(data.response).recordingUrl)
      
   if(typeof(phone) == 'number') {
      phone = String(phone)
   }
   else {
      phone = phone
   }
   console.log('phone===', phone)
   console.log('phone===', JSON.parse(JSON.stringify(phone)))
   console.log('phone===', typeof(phone))
   var callDirection = getCallDirection();
  var contactname = $("#contactname").val();
  console.log("status=>",$("#status").val());
    var ticketObject = {};
    ticketObject.phone = phone;
console.log('contactname in ticket create', contactname)
    ticketObject.name = contactname;
    // ticketObject.duration = $("#duration").val();
    ticketObject.source = 3;
console.log('callDirection ====', callDirection)

    if (callDirection == "incoming") {
        ticketObject.description = $("#description").val();
        ticketObject.subject = `Incoming call from ${phone}`;
    } else {
        ticketObject.description = $("#description").val();
        ticketObject.subject = `Outbound call to ${phone}`;
    }
    
   // ticketObject.status = 3;
   // ticketObject.priority = 2;
    //ticketObject.custom_fields = {"cf_duration":parseFloat(duration)};
    console.log("calldata======>", ticketObject);
    $(".recentTickets").hide();

    var headers = {
        "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
        "Content-Type": "application/json"
    };
    var options = {
        headers: headers,
        body: JSON.stringify(ticketObject)

    };

    var url = "<%= iparam.freshdeskDomain %>" + "/api/channel/v2/tickets";

      client.request.post(url, options)
        .then(
            function (ticket) {
                var result = jQuery.parseJSON(ticket.response);
                console.log(result,"result");

              if (JSON.parse(data.response).duration != null) {
               console.log('duration add in ticket after ticket creation')
                 let requestBody = {}
                 requestBody.private = false;

                 if (JSON.parse(data.response).recordingUrl !== 'null' && JSON.parse(data.response).recordingUrl !== null) {
                    requestBody.body = 'Call Recording: ' + JSON.parse(data.response).recordingUrl + "<br> Call Duration: " + JSON.parse(data.response).duration;
                 }
                 else {
                    requestBody.body = "Call Duration: " + JSON.parse(data.response).duration;
                 }
                 var headers = {
                  "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                    "Content-Type": "application/json"
                 };
                 var options = {
                    headers: headers,
                    body: JSON.stringify(requestBody)
                 };
                 var url = "<%= iparam.freshdeskDomain %>" + "/api/v2/tickets/" + result.id + "/notes";

                 client.request.post(url, options)
                    .then(
                       function (notes) { console.log('notes ====== ', notes) })
              }
              displayStatus('success', 'Ticket #'+result.id+' Created Successfully.');
              $(".ticketCreateButton").prop('disabled', false);
              //document.getElementById("logcreate").disabled = false;

              $("#description").val('')
            
            var headers = {
               "Content-Type": "application/json"
            };
            console.log('contactname====================', contactname)
            console.log('testt = ', JSON.stringify({exotelSid: callSid, ticketId: result.id, contactName: contactname, contactId: result.requester_id}))
            var options = {
               headers: headers,
               body: JSON.stringify({exotelSid: callSid, ticketId: result.id, contactName: contactname, contactId: result.requester_id, agentId : parseInt(localStorage.getItem('loggedInId'))})
            };
            var url = localStorage.getItem('endpoint_url') + "/saveTicketDetails";
         
            client.request.post(url, options)
               .then((ticketStored) => {
                  console.log('ticketStored===', ticketStored)
               })

               /* $(".recentTickets").show();
               $(".Reply").hide();
               
               $('#callHistoryList').show();
               $(".callerDetailsPage").hide();  */

            },
            function (error) {
                console.log(error);
                console.log(error.response);
                if(JSON.parse(error.response).errors[0].field == 'name') {
                  displayStatus('danger', 'Name should not be empty');
                }
            });
  

   })

}




// $('.nav-tab').click(function(e) {
//   //Toggle tab link
//   $(this).addClass('nav-tab-active').siblings().removeClass('nav-tab-active');

//   //Toggle target tab
//   $($(this).attr('href')).addClass('active').siblings().removeClass('active');
// });


function contactDeepLink(contactId) {
   console.log('contactId', contactId)
   client.interface.trigger("click", {id: "contact",value: parseInt(contactId) })
      .then(function(data) {
         console.log('data = ', data)
      }).catch(function(error) {
      console.log('error = ', error)
      });
}

function clickRecentTicket() {
   console.log('clickRecentTicket')
   var din = $('#w3mission').val();
   
    
    console.log('din', din)
    console.log('din.contact==', JSON.parse(din).contact[0])
   if(JSON.parse(din).contact[0] != undefined) {
      ticketHistoryShow(JSON.parse(din).contact[0].id);
   }
   else{
      ticketsHistory ='<div class="card bg-primary text-white bg-info mb-3" >' +
                                    '<div class="card-body text-center">No Tickets are Available</div>' +
                                    '</div><br>'
      $('#ticketss').empty()
      $('#ticketss').append(ticketsHistory)
      $(".recentTickets").show()
   }
   $('#ticket-history').addClass("nav-tab-active active");
   $('#call-notes').removeClass("nav-tab-active active")
   $('#myTabContent').hide()
   $('#createTicketNotes').hide()
}

function clickCallNotes() {
   console.log('clickCallNotes')
   $('#call-notes').addClass("nav-tab-active active");
   $('#ticket-history').removeClass("nav-tab-active active")
   
   $('#myTabContent').show()
   $('#createTicketNotes').show()
   $(".recentTickets").hide()

}


function addTicketNotes(ticketId) {
   $(".notesAddButton").children().prop('disabled',true);

   console.log('addTicketNotes==', ticketId)
   addExistingTicketNotes(ticketId)
}


function addExistingTicketNotes(ticketId) {
   let callSid = getCallSid();
   var contactname = $("#contactname").val();
   let reqObject = {
      exotelSid: callSid
   }
   var headers = {
      "Content-Type": "application/json"
   };
   var options = {
      headers: headers,
      body: JSON.stringify(reqObject)
   };
   var url = localStorage.getItem('endpoint_url') + "/getCallsDetails";

   client.request.get(url, options)
      .then((data) => {
         console.log('getCallDetails resss= ', JSON.parse(data.response))
         console.log('getCallDetails resss= ', JSON.parse(data.response).duration)
         console.log('getCallDetails resss= ', JSON.parse(data.response).recordingUrl)
         
               
                let logId = parseInt(localStorage.getItem('loggedInId'));
                console.log('logId', logId)
                var logName = localStorage.getItem('loggedInName')

	let requestBody = {
      body: `Notes added by ${logName}: `+$("#description").val(), 
      private: false
   }
   var headers = {
      "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
      "Content-Type": "application/json"
  };
  var options = {
      headers: headers,
      body: JSON.stringify(requestBody)
  };

  var url = "<%= iparam.freshdeskDomain %>" + "/api/v2/tickets/"+ticketId+"/notes";

  client.request.post(url, options)
      .then(
          function (addNotes) {
               var result = jQuery.parseJSON(addNotes.response);
               console.log(result,"result");
               if(JSON.parse(data.response).duration != null) {
				
                     let requestBody = {}
                     requestBody.private = false;
                     if(JSON.parse(data.response).recordingUrl !== 'null' && JSON.parse(data.response).recordingUrl !== null) {
                     requestBody.body = 'Call Recording: ' + JSON.parse(data.response).recordingUrl +"<br> Call Duration: "+ JSON.parse(data.response).duration
                     }
                     else{
                        requestBody.body = "Call Duration: "+ JSON.parse(data.response).duration
                     }
                                          
                     var headers = {
                        "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                        "Content-Type": "application/json"
                     };
                     var options = {
                        headers: headers,
                        body: JSON.stringify(requestBody)
                     };
                     var url = "<%= iparam.freshdeskDomain %>" + "/api/v2/tickets/"+result.ticket_id+"/notes";

                     client.request.post(url, options)
                        .then(
                              function (notes) {console.log('notes ====== ', notes)})
                  }
                displayStatus('success', 'Notes is added to Ticket #'+result.ticket_id+' Successfully');
                
                $(".notesAddButton").children().prop('disabled',false);

                $("#description").val('')
			  var headers = {
               "Content-Type": "application/json"
            };
            console.log('contactname====================', contactname)
            let saveTicketRequest = {
               exotelSid: callSid, 
               ticketId: result.ticket_id,
               agentId : parseInt(localStorage.getItem('loggedInId'))
            }
            if(JSON.parse($('#w3mission').val()).contact[0] != undefined && JSON.parse($('#w3mission').val()).contact[0].id != undefined) {
               saveTicketRequest.contactName = contactname;
               saveTicketRequest.contactId = $('#contactId').val();
            }
            var options = {
               headers: headers,
               body: JSON.stringify(saveTicketRequest)
            };
            var url = localStorage.getItem('endpoint_url') + "/saveTicketDetails";
         
            client.request.post(url, options)
               .then((ticketStored) => {
                  console.log('ticketStored===', ticketStored)
               })

          },
          function (error) {
              console.log(error);
              console.log('error.response.description', JSON.parse(error.response).description)
              if(JSON.parse(error.response).description == 'Validation failed') {
               displayStatus('danger', 'Empty Notes cannot be added to the ticket');
              } 
          });
         
   })
}

function ticketHistoryShow(requesterId) {
   console.log('ticketHistoryShow===', requesterId)
   var statusMap = {
      Open: 2,
      Pending: 3,
      Resolved: 4,
      Closed: 5,
      Waiting_on_Customer: 6,
      Waiting_on_Third_Party : 7
  };
   var options = { 
      "headers": {
          "Content-Type": "application/json",
          "Authorization": '<%= encode(iparam.freshdeskApikey) %>'
      }
  };
  var url = "<%= iparam.freshdeskDomain %>" + "/api/v2/tickets?requester_id="+requesterId+"&per_page=30";
  console.log(url);
  client.request.get(url, options)
      .then((result) => addTicketsData(result, statusMap), 
      function (error) {
         console.log(error);
         ticketsHistory ='<div class="card bg-primary text-white bg-info mb-3" >' +
                                    '<div class="card-body text-center">No Tickets are Available</div>' +
                                    '</div><br>'
      $('#ticketss').empty()
      $('#ticketss').append(ticketsHistory)
      $(".recentTickets").show()
     });
}

function addTicketsData(result, statusMap) {
   var res = jQuery.parseJSON(result.response);
   console.log("tickets===========>", res);


   var ticketsHistory ='';
   if (res.length != 0) {
      ticketsHistory += `<div class="merge-ticket-sec sec-wdth bx-shadow bdr-rds10 bg-white min-hgt500">`
      $.each(res, function (index, res) {
        
      ticketsHistory += 

      `<div class="merge-content-body" style="height: 60px !important;">
            <div class="col-12">
         <div class="list-sec pt-xl-3 pl-xl-3 pr-xl-3 pb-xl-3 row align-items-center">
            <div class="row align-items-center" style="width: 500px !important;">
               <div class="col-2 pdrgt0" style="">
               <div class="ticketIcon" onClick="ticketDeepLink('${res.id}')" data-toggle="tooltip" title="go to ticket">
               <button class="btn btn-round-white" style="min-width: 45px !important; margin-top: 7px !important;">
                  
            <svg class="ticket" width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false"><path d="M.267 12.874V10.23a3.824 3.824 0 013.818-3.831h23.831a3.825 3.825 0 013.818 3.831v2.644l-1.018.563c-1.076.595-1.736 1.665-1.736 2.83s.66 2.235 1.736 2.83l1.018.563v2.644a3.824 3.824 0 01-3.818 3.831H4.085a3.825 3.825 0 01-3.818-3.831V19.66l1.018-.563c1.076-.595 1.736-1.665 1.736-2.83s-.66-2.235-1.736-2.83l-1.018-.563zm4.72 3.393c0 1.948-1.107 3.648-2.753 4.558v1.478c0 1.026.829 1.857 1.851 1.857h23.831a1.855 1.855 0 001.851-1.857v-1.478c-1.646-.91-2.753-2.61-2.753-4.558s1.107-3.648 2.753-4.558v-1.478a1.854 1.854 0 00-1.851-1.857H4.085a1.855 1.855 0 00-1.851 1.857v1.478c1.646.91 2.753 2.61 2.753 4.558zm5.981-5.14h10.065a3.825 3.825 0 013.818 3.831v2.6a3.824 3.824 0 01-3.818 3.831H10.968a3.825 3.825 0 01-3.818-3.831v-2.6a3.824 3.824 0 013.818-3.831zm0 1.973a1.855 1.855 0 00-1.851 1.857v2.6c0 1.026.829 1.857 1.851 1.857h10.065a1.855 1.855 0 001.851-1.857v-2.6a1.854 1.854 0 00-1.851-1.857H10.968z"></path></svg>
            
               </button>
            
            </div>
               </div> 
         
         <div class="col-6 pdrgt0" style="">
         <div class="desc">
            <p>${res.subject} #${res.id}</p>
            <span class="w100">Status: ${Object.keys(statusMap).find(key => statusMap[key] === res.status).replace(/_/g, " ")} . ${ moment(res.created_at).fromNow()}</span>
         </div>
         
         </div>
         
         <div class="col-4 text-right pdlft0">
         <div class="call-over-action notesAddButton" onClick="addTicketNotes('${res.id}')">
            <button class="btn btn-round-white" >
               <span style="font-size: 10px;">Add Note<span>
            </button>
         
         </div>
         </div>
            </div>
         </div>
         </div>
         </div>
         `
      }) 
      
     }

      else{
         ticketsHistory ='<div class="card bg-primary text-white bg-info mb-3" >' +
                                    '<div class="card-body text-center">No Tickets are Available</div>' +
                                    '</div><br>'
      }
      $('#ticketss').empty()
      $('#ticketss').append(ticketsHistory)
      $(".recentTickets").show()

}


function ticketDeepLink(ticketId) {
   client.interface.trigger("click", {id: "ticket",value: ticketId })
   .then(function(data) {
   console.log('data = ', data)
   }).catch(function(error) {
   console.log('error', error)
   });
}

function getCallSid() {
   console.log(`getCallSid : $('#callSid').val() === ${$('#callSid').val()}`)
   console.log(`getCallSid : $('#callCallSid').val() === ${$('#callCallSid').val()}`)
   let callSid = $('#callSid').val() == '' || $('#callSid').val() == undefined ? $('#callCallSid').val() : $('#callSid').val();
   console.log('getCallSid : callSid ===', callSid)
   return callSid;
}

function getCallDirection() {
   console.log(`getCallDirection : $('#callerDirection').val() === ${$('#callerDirection').val()}`)
   console.log(`getCallDirection : $('#callHistoryCallerDirection').val() === ${$('#callHistoryCallerDirection').val()}`)
   console.log('object ==== ', $('#callHistoryCallerDirection').val())
   let callDirection = $('#callerDirection').val() == '' || $('#callerDirection').val() == undefined ? $('#callHistoryCallerDirection').val() : $('#callerDirection').val();
   console.log('getCallSid : callDirection ===', callDirection)
   return callDirection;
   
   
}