 let footerHTML = ` 
 <div class="dial-footer">
 <div class="col-12 footer-menu">
 <div class="row justify-content-center ">
 <div class="nav align-items-center">
 <ul> 
 <li class="nav-item ">
 <a class="nav-link" href="#" data-toggle="tooltip" title="Call History" onClick="footerClick()">   
 <svg class="clock" width="25" height="25" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 30 30" style="enable-background:new 0 0 30 30;" xml:space="preserve">
 <style type="text/css">
 .clock .st0{fill:none;stroke:#92a2b1;stroke-width:2;stroke-linecap:round;stroke-miterlimit:10;}
 .clock .st1{fill:none;stroke:#92a2b1;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}
 </style>
 <polyline class="st0" points="14.7,10.2 14.7,15.7 20.2,15.7 "/>
 <polyline class="st1" points="8.4,11.3 8.4,4.8 1.8,4.8 "/>
 <path class="st1" d="M24.5,8.4c-0.8-1.2-1.7-2.3-2.9-3.2"/>
 <path class="st1" d="M27.4,16.6c0.2-1.6,0.1-3.2-0.3-4.7"/>
 <path class="st1" d="M7.1,6.2C1,10.7,1,19.9,6,24.8c6.1,6,17.2,3.2,20.5-4.4"/>
 <path class="st1" d="M17.5,2.9c-1.4-0.3-2.9-0.3-4.3-0.1"/>
 </svg>
 </a>
 </li>  
 </ul> 
 </div>
 </div>
 </div> 
 </div>`
function footerClick() {
    if($('.callerDetailsPage').is(':visible') && ($("#description").val() != '')){
    client.interface.trigger("showConfirm", {
        title: "Warning!",
        message: "Do you want to redirect the page without saving the changes?", saveLabel: "Yes", cancelLabel: "No"
      }).then(function(result) {
        console.log('res = ='+ JSON.stringify(result))
         console.log(result.message,"res");
         if(result.message == "Yes"){
            callHistory();            
         }
  }).catch(function(error) {
      if(error) console.error('error = ', error)
      });
    }
    else {
        callHistory();
    }
}


            
function incomingScreenPop(callDetail, apiValue) {
                
    console.log('JSON.parse=='+JSON.parse(callDetail)) 
    var callData = JSON.parse(callDetail);
    console.log('callData===', JSON.parse(callData))
    console.log('JSON.parse(callDetail).CallFrom', JSON.parse(callData).CallFrom)
    var callStatus = JSON.parse(callData).Status;
    var callednum = JSON.parse(callData).CallFrom;
   /*  var callDuration = JSON.parse(callData).Duration;
    var callDirection = JSON.parse(callData).Direction;

    var DialCallSttaus =JSON.parse(callData).DialCallSttaus; */

    /* callData =null;
    
    var callStatus = 'free';
    var callednum = "9786108325";
    var callDuration ="15 minutes";
    var callDirection = "inbound";*/
    console.log(callednum,"callednum");
    
    console.log('callStatus='+callStatus);
    console.log('apiValue====', apiValue)
    console.log('apiValue====', typeof(apiValue))
    if(apiValue == 'pop' && callStatus == 'busy') {
        /* callData ={
            "CallFrom":callednum,
            "Status": callStatus,
            "Duration": callDuration,
            "Direction": callDirection
        }; */
        $('.recentTickets').show();
        $(".Reply").hide();
        $(".ModalPopup").hide();
        $(".showContacts").hide();
        $('#callHistoryList').hide();

        fetch_contact(callednum, "", JSON.parse(callData));
    }
    else if(apiValue=='answered'){

        //cf_callduration

         /* callData ={
            "CallFrom":callednum,
            "Status": callStatus,
            "Duration": callDuration,
            "Direction": callDirection
        }; */
      // ticketPage(callData);

       /* $('#callHistoryList').show();
       $(".callerDetails").hide(); */

       
       /* $('#ticketss').hide();
       $(".callerDetailsPage").show();   */
       
       console.log('callerDetailsPage=====', $('.callerDetailsPage').is(':visible')) //call notes and ticket history
       console.log('callHistoryList=====', $('.callHistoryList').is(':visible')) //call history page
       console.log('callerDetails=====', $('.callerDetails').is(':visible')) //inbound screen pop
       if($('.callerDetails').is(':visible')) {
        //$('.callHistoryList').show()
        callHistory()
       }
       let sid = JSON.parse(callData).CallSid;
       console.log('sid in ans = ', sid)
       addDurationAndRecordingUrl(sid);

    }

    else if(apiValue == 'missed') {
        
        //socket.close();

        //socket.disconnect(true)

        if($('.callerDetails').is(':visible')) {
            callHistory();
        }
        let sid = JSON.parse(callData).CallSid;
        console.log('sid in ans = ', sid)
        let reqObject = {
            exotelSid: sid
        }
        console.log('reqObject = ', reqObject)
        var headers = {
            "Content-Type": "application/json"
        };
        var options = {
            headers: headers,
            body: JSON.stringify(reqObject)
        };
        var url = localStorage.getItem('endpoint_url') + "/getCallDetails";

        client.request.get(url, options)
            .then((data) => {
                let callEndDetail = JSON.parse(data.response)[0];
                console.log('EndDetail', callEndDetail)
                console.log('callEndDetail.ticketId = ', callEndDetail.ticketId)
                
                var ticketObject = {};
                var fromNum = JSON.parse(callData).CallFrom;
                console.log('callEndDetail.contactName = ', callEndDetail.contactName)
                ticketObject.phone = fromNum;
                
                ticketObject.name = callEndDetail.contactName != null ? callEndDetail.contactName : 'Unknown';
                // ticketObject.duration = $("#duration").val();
                ticketObject.source = 3;
                ticketObject.subject = "Missed Call from " + fromNum;
                var headers = {
                    "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                    "Content-Type": "application/json"
                };
                var options = {
                    headers: headers,
                    body: JSON.stringify(ticketObject)

                };
                var url = "<%= iparam.freshdeskDomain %>" + "/api/channel/v2/tickets";

                client.request.post(url, options)
                    .then(
                        function (ticket) {
                            var result = jQuery.parseJSON(ticket.response);
                            console.log('Missed Call Ticket Created' + result.id);
                            
                            var options = {
                                headers: headers,
                                body: JSON.stringify({exotelSid: sid, ticketId: result.id, contactName: ticketObject.name, contactId: result.requester_id, agentId : parseInt(localStorage.getItem('loggedInId'))})
                             };
                             var url = localStorage.getItem('endpoint_url') + "/saveTicketDetails";
                          
                             client.request.post(url, options)
                                .then((ticketStored) => {
                                   console.log('Missed call ticketStored===', ticketStored)
                                })

                        })
            })
    }
   
}
var callDetails={};
/** check contact is exist or not **/
function fetch_contact(phone, callmessage, calldata) {

    client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/contacts?phone=" + phone, {
        headers: {
            "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
            "Content-Type": "application/json"
        }
    })
        .then(function (contact) {
            callDetails.contact = jQuery.parseJSON(contact.response);
            callDetails.company = '';
            console.log("contact=====>", callDetails);
            if (callDetails.contact.length != 0) {
                console.log("============already contact========");
                console.log('callDetails.contact===', callDetails.contact[0].company_id)
                if(callDetails.contact[0].company_id != null){
                    client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/companies/" + callDetails.contact[0].company_id, {
                        headers: {
                            "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                            "Content-Type": "application/json"
                        }
                    }).then(function (company) {
                        console.log('JSON.parse(company.response).name===', JSON.parse(company.response).name)
                        callDetails.company = JSON.parse(company.response).name
                        contactPage(callDetails, "alreadyexist",calldata);
                    })
                }
                else {
                    contactPage(callDetails, "alreadyexist",calldata);
                }
                
            } else {
                callDetails.phone = phone
                callDetails.name = 'Unknown'
             console.log("============new contact========");
                contactPage(callDetails, "newcontact",calldata);

               // contactCreation();
            }
        },
            function (error) {
                console.log(error);
            });
}
var contact =null;
function contactPage(param1, param2,call) {
    var calldata =JSON.stringify(calldata);
    if (param2 == "alreadyexist") {
        console.log("alreadyexist===>", param1.contact);
        var contactObj = param1.contact[0];
        postContactDetails(call.CallSid, contactObj.id, contactObj.name);

    } else if (param2 == "newcontact") {
    console.log("new contact===>", param1);
    console.log('callData=== callfrom', call.CallFrom)

        var contactObj = null;
    }
    console.log('newticketCreate(${param1})', "newticketCreate('+'\''+param1+'\''+')")

    $(".callerDetails").show();
    $(".callerDetails").empty();
    $("body.callerDetails").css("overflow", "hidden");
      
    if(contactObj == null){
        contact = unknownScreenPop(param1.name, param1.phone, 'incoming', param1, call.CallSid);
}else if(contactObj != null){
console.log("contact object is not null");
console.log('param1.company = ', param1.company)
contact = knownScreenPop(contactObj.name, contactObj.phone, param1.company, 'incoming', param1, call.CallSid);
}


contact += footerHTML;
 
$(".callerDetails").append(contact);

} 


function showError(msg) {
    console.error(msg);
}

function displayStatus(type, message) {
    client.interface.trigger('showNotify', {
        type: type,
        message: message
    });
}



function unknownScreenPop(name, phone, direction, contactParam, callSid) {
    console.log('unknownScreenPop')
    let contact ='<div class="incoming-call-sec sec-wdth bdr-rds10 min-hgt500">'+
    '<div class="col-12">'+
       '<div class="caller-profile text-center">'+
          '<div class="col-12">'+
             '<div class="row justify-content-md-center">'+
                '<div class="call-blink">'+
                   '<div class="rounded-sec row align-items-center">'+
                      '<span>U</span>'+
                      '<div class="wave">'+
                      '</div>'+
                      '<div class="wave1">'+
                      '</div>'+ 
                   '</div>'+
               '</div>'+
             '</div>'+
          '</div>'+
       '</div>'+ 
       '<div class="caller-details text-center">'+
          '<h4 class="name">'+name+'</h4>'+
         '<p class="number">'+phone +'</p>'+
       '</div>'+'<div class="call-action text-center">'+
          '<div class="row align-items-end min-hgt120"><br><br>'+
             '<div class="col-6">'+
             '<input type="hidden" value="unknown" id="caller">'+
             '<input type="hidden" value='+direction+' id="callerDirection">'+
         `<textarea style="display: none;" id="w3mission" rows="4" cols="50">
         ${JSON.stringify(contactParam)}
         </textarea>`+
         `<textarea id="callSid" style="display: none;">${callSid}</textarea>`+
         '<button id="logcreate" style="background-color:#1f3f58;color: #f9f9f9;" data-num="'+{"name":"name1"}+'" onClick="newticketCreate(this)" class="pull-right btn call-atten w100">Add Note</button>'+
          '</div>'+
       '</div>'+
    '</div>'+
 '</div>';
 return contact;
}

function knownScreenPop(name, phone, companyName, direction, contactParam, callSid) {
    console.log('knownScreenPop')
    let contact =
    '<div class="incoming-call-sec sec-wdth bdr-rds10 min-hgt500">'+
'<div class="col-12">'+
'<div class="caller-profile text-center">'+
 '<div class="col-12">'+
    '<div class="row justify-content-md-center">'+
       '<div class="call-blink">'+
          '<div class="rounded-sec row align-items-center">'+
             '<span>'+ name.substring(0, 1) +'</span>'+
             '<div class="wave">'+
             '</div>'+
             '<div class="wave1">'+
             '</div>'+
          '</div>'+
      '</div>'+
    '</div>'+
 '</div>'+
'</div>'+
'<div class="caller-details text-center">'+
 '<h4 class="name">'+ name +'</h4>'+
'<p class="number">'+ phone +'</p>'+ 
(companyName !== '' ? '<span class="des-tag">'+companyName+'</span>' : '') +      
'</div>'+'<div class="call-action text-center">'+
 '<div class="row align-items-end min-hgt120"><br><br>'+
    '<div class="col-6">'+
        '<input type="hidden" value="'+name+'" id="caller">'+
    '<input type="hidden" value="'+direction+'" id="callerDirection">'+
    // '<input type="hidden" value="'+call.Duration+'" id="callerduration">'+
    `<textarea style="display: none;" id="w3mission" rows="4" cols="50">
    ${JSON.stringify(contactParam)}
    </textarea>`+
    `<textarea id="callSid" style="display: none;">${callSid}</textarea>`+
    '<button style="background-color:#1f3f58;color: #f9f9f9;" id="logcreate" data-num="'+{"name":"name1"}+'" onClick="newticketCreate(this)" class="pull-right btn call-atten w100">Add Note</button>'+
    '</div>'+
'</div>'+
'</div>';
return contact;
}

function addDurationAndRecordingUrl(sid) {
    console.log('addDurationAndRecordingUrl::sid = ', sid)
    let reqObject = {
        exotelSid: sid
    }
    console.log('reqObject = ', reqObject)
    var headers = {
        "Content-Type": "application/json"
    };
    var options = {
        headers: headers,
        body: JSON.stringify(reqObject)
    };
    var url = localStorage.getItem('endpoint_url') + "/getCallDetails";

    client.request.get(url, options)
        .then((data) => {
            console.log('resss= ', JSON.parse(data.response))
            let callEndDetail = JSON.parse(data.response)[0];
            console.log('callEndDetail', callEndDetail)
            console.log('callEndDetail.duration', callEndDetail.duration)
            console.log('callEndDetail.recordingurl', callEndDetail.recordingUrl)
            
            let recordingUrl = callEndDetail.recordingUrl !== 'null' ? callEndDetail.recordingUrl :  ''
            if (callEndDetail.ticketId !== 'null') {
                var headers = {
                    "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                    "Content-Type": "application/json"
                };    
                let requestBody = {}
                requestBody.private = false;

                if (recordingUrl !== '') {
                    requestBody.body = 'Call Recording: ' + recordingUrl + "<br> Call Duration: " + callEndDetail.duration;
                }
                else {
                    requestBody.body = "Call Duration: " + callEndDetail.duration;
                }
                console.log('requestBody add recording URL', requestBody)

                var options = {
                    headers: headers,
                    body: JSON.stringify(requestBody)
                };
                var url = "<%= iparam.freshdeskDomain %>" + "/api/v2/tickets/" + callEndDetail.ticketId + "/notes";

                client.request.post(url, options)
                    .then(
                        function (notes) { console.log('notes ====== ', notes) })
                }   
            
            
        }, function(error){
            if(error) console.error('Error : ' + error)
        })
}

function postContactDetails(callSid, contactId, contactName) {
    console.log('postContactDetails', callSid, contactId, contactName)
    let contactDetials = {
        exotelSid: callSid,
        contactId: JSON.stringify(contactId),
        contactName: contactName
    }
    console.log('contactDetials ====== '+ contactDetials)
    var headers = {
        "Content-Type": "application/json"
    };
    var options = {
        headers: headers,
        body: JSON.stringify(contactDetials)
    };
    var url = localStorage.getItem('endpoint_url') + "/postContactDetails";
    console.log('url', url)
    client.request.post(url, options, {
        headers: {
            "Content-Type": "application/json"
        }
    }).then(function (data) {
        console.log('data from postContactDetails==== ', data)
    })
}