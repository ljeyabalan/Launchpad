 var MIDDLEWARE_URL = "https://318edd4d.ngrok.io";
 var SOCKET_URL = "https://318edd4d.ngrok.io/";

let STATUS_CALLBACK = "https://318edd4d.ngrok.io/ans"


$(document).ready(function () {
    app.initialized()
        .then(function (_client) {
            window.body = $('body');
            window.client = _client;
            client.instance.resize({ height: "500px" });
            addEventListeners();

            $(".mapListPage").hide();  
            $(".ModalPopup").show();
            //store exotelSid
            client.iparams.get("exotelSid").then((sid) => {
                let exotelSid = sid.exotelSid
                console.info('Main:App Initialized::exotelSid : ', exotelSid)
                localStorage.setItem('exotelSid', exotelSid);
            },
            function(error) {
                console.error('Main:App Initialized::exotelSid Error :', error)
                displayStatus('danger', 'Main:App Initialized::exotelSid Error')
            })

            client.iparams.get("exotelDomain").then((exotelCluster) => {
                console.log('Main:App Initialized::exotelDomain : ', exotelCluster.exotelDomain)
                let domain = exotelCluster.exotelDomain == "Singapore" ? '@api.exotel.com' : '@api.in.exotel.com';
                localStorage.setItem('exotelDomain', domain);
            },function(error) {
                console.error('Main:App Initialized::ExotelDomain Error :', error)
                displayStatus('danger', 'Main:App Initialized::ExotelDomain Error')
            })

            //store loggedInUser data
            client.data.get("loggedInUser").then(
                function (data) {
                    console.info('Main:App Initialized::loggedInUser data : ', data)
                    localStorage.setItem('loggedInId', data.loggedInUser.id)
                    localStorage.setItem('loggedInName', data.loggedInUser.contact.name)
                    localStorage.setItem('loggedInRoleIds', data.loggedInUser.role_ids)
            }).catch(error => {
                console.error('Main:App Initialized::loggedInUser Error :', error)
                displayStatus('danger', 'Main:App Initialized::loggedInUser Error')
            })

            //store endpoint_url
            client.iparams.get("endpoint_url").then((endpoint) => {
                let endpoint_url = endpoint.endpoint_url
                console.info('Main:App Initialized::endpoint_url : ', endpoint_url)
                localStorage.setItem('endpoint_url', endpoint_url);
            }).catch(error => {
                console.error('Main:App Initialized::endpoint_url Error :', error)
                displayStatus('danger', 'Main:App Initialized::endpoint_url Error')
            })

            var socket;
                   /*  if(sessionStorage.getItem('testConnect') != null && sessionStorage.getItem('testConnect') === "true") {
                            
                    }
                    else { */
                        console.log('SOCKET CONNECTION DONE NOW')
                        socket = io(localStorage.getItem('endpoint_url') + '/');
                    /* } */

                    
                    //var socket = io(localStorage.getItem('endpoint_url') + '/');
                    /* if(localStorage.getItem('connectionTest') != null && localStorage.getItem('connectionTest') === "true") {
                            
                    }
                    else {
                        localStorage.setItem('connectionTest', "true")
                        socket = io(localStorage.getItem('endpoint_url') + '/');
                    } */
                     
                    //socket.on('end', function (){ socket.disconnect(0); socket.open(); });

/*                     console.log('socket ==== ', socket)
                    console.log('socket ==== ', socket.io)
                    console.log('socket ==== ', socket.id)
                    console.log('socket ==== ', socket)

                    console.log('socket ==== ', socket.connected) */

                    socket.on('connect', function () {
                        console.log('connect ==== ')
                         if(sessionStorage.getItem('testConnect') != null && sessionStorage.getItem('testConnect') === "true") {
                            console.log('testtttttttt')
                        }
                        else {
                            sessionStorage.setItem('testConnect', "true")
                            console.log('tetttttt', sessionStorage.getItem('testConnect'))
                        } 
                    })
                    
                    socket.on('outbound_call', function (data) {
                        console.info('Main:App Initialized::Socket : outbound_call data : ', JSON.stringify(data))
                        console.info('Main:App Initialized::Socket : outbound_call data.callInfo : ', (data.callInfo))
                        console.info('Main:App Initialized::Page Info : Call Note & Ticket history Page : ' + $('.callerDetailsPage').is(':visible') + ' Call History Page : ' +  $('.callHistoryList').is(':visible') + ' Inbound Screen Pop : ' + $('.callerDetails').is(':visible'))
                        /* If Inbound screen pop page is showing after call ends, then page redirects to call History page */
                        if($('.callerDetails').is(':visible')) {
                        callHistory()
                        }
                        addDurationAndRecordingUrl(data.callInfo.CallSid)

                        /* socket.close();
                        setTimeout(() => {
                            socket.connect();
                        }, 5000);
                        
                        sessionStorage.removeItem('testConnect'); */
                })
                
                


                socket.on('incoming_call', function (data) {
                    console.log('dtatatat='+ JSON.stringify(data));
                     //screenPop()
                     console.log(JSON.stringify(data.callInfo))
                     console.log('apiValue = '+JSON.parse(data.apiValue))
                     console.log('DialWhomNumber = '+data.callInfo)
                     console.log('DialWhomNumber = '+jQuery.parseJSON(JSON.parse(data.callInfo)).DialWhomNumber)
                     console.log('DialWhomNumber = '+typeof(jQuery.parseJSON(JSON.parse(data.callInfo)).DialWhomNumber))

                           let logId = parseInt(localStorage.getItem('loggedInId'));
                           let reqObject = {
                               phoneNumber: jQuery.parseJSON(JSON.parse(data.callInfo)).DialWhomNumber
                            }
                            var headers = {
                               "Content-Type": "application/json"
                            }; 
                            var options = {
                               headers: headers,
                               body: JSON.stringify(reqObject)
                            };
                            var url = localStorage.getItem('endpoint_url') + "/getMappedUserByMobileNumber";
                         
                            client.request.get(url, options)
                               .then((mappedUser) => {
                                   console.log('mappedUser === ', mappedUser)
                                   console.log('mappedUser === ', JSON.parse(mappedUser.response).agentId) 
                                   console.log('mappedUser === ', typeof(JSON.parse(mappedUser.response).agentId))
                                   console.log('logId = ', logId)
                                   console.log('logId', typeof(logId))
                                   if(JSON.parse(mappedUser.response).agentId != 0 && logId == JSON.parse(mappedUser.response).agentId) {
                                       console.log('USER IS MAPPED')
                                       console.log('data.callInfo====', data.callInfo)

                                   client.interface.trigger("show", {id: "softphone"})
                                   .then(function(openCTI) {
                                       console.log('openCTI === '+ openCTI)
                                       incomingScreenPop(data.callInfo, JSON.parse(data.apiValue))
                                   }).catch(function(error) {
                                   console.log('error:', error)
                                   });
                                       
                                   }
                               }, function(error){
                                   if(error) console.error('Error :', error)
                               })
                   
                   });

            client.events.on('app.activated', function () {
                callHistory();
            });
            
    }).catch(function(err){
        console.error('Main:App Initialized::error : ', err)
        displayStatus('danger', 'Main:App Initialized::error')
    }) 
});

function addEventListeners() {
    /* Click-to-call functionality */
    client.events.on("cti.triggerDialer", clickToCallEvent)
}

function clickToCallEvent(event) {
    console.info('Main:clickToCallEvent::event : '+ event + ' Number : ' + event.helper.getData().number)
    makeOutboundCall(event.helper.getData().number)
  };
       function callHistory(...args) {
        console.info('Main:callHistory::args : ', args)
        let openingHTML = `<div class="call-history-sec sec-wdth bx-shadow bdr-rds10 bg-white min-hgt500">
           <div class="call-head pt-xl-2 pl-xl-3 pr-xl-3 pb-xl-2">
           <div class="row">
               <div class="col-5 text-left">`
                let logId = parseInt(localStorage.getItem('loggedInId'));
                let roles = localStorage.getItem('loggedInRoleIds');
                console.info('Main:callHistory::Roles of logged in user : ', roles)
          
            var headers = {
                "Content-Type": "application/json"
            };
            var options = {
                headers: headers,
                body: JSON.stringify({agentId : logId})
            };
            var url = localStorage.getItem('endpoint_url') + "/getMappedNumber";

            client.request.get(url, options)
                .then((mappedNumber) => {
                    console.info('Main:callHistory::mappedNumber(/getMappedNumber API) : ', JSON.parse(mappedNumber.response)[0])
                    let mappedPhoneNumber;
                console.info('Main:callHistory::mappedNumber(/getMappedNumber API) Length : ',(JSON.parse(mappedNumber.response).length))
                mappedPhoneNumber = (JSON.parse(mappedNumber.response).length != 0) ? JSON.parse(mappedNumber.response)[0].exotelNumber : '';
                let mappedNumberHTML = `<div class="number-dropdown">
                <select style="width: 120px">
                    <option>${mappedPhoneNumber}</option>
                   
                </select>
            </div>   `

            client.iparams.get("roles").then (
                function(data) {
                    console.log('iparams data = ', data)
                    console.log('iparams roles = ', data.roles)
                    let roleids = [];
                    data.roles.forEach(role => {
                        roleids.push(parseInt(role.split(': ')[1]))
                    });
                    console.log('roleids = ', roleids)
                    let userMappingIconHTML = '';
                    if(roleids.some(roleId => roles.includes(roleId))) {
                        userMappingIconHTML = `<button  class="fa  fa-gear" href="#" onClick="mappingUsers()" data-toggle="tooltip" data-placement="top" 
                        title="User Mapping" style="margin-left: 315px; margin-top: -24px;">
                        </button> `
                    }
                
           let headingHTML = `</div>
             </div>  
           </div>
           <div class="history-calls">
           <div class="history-head pt-xl-2 pl-xl-3 pr-xl-3 pb-xl-2">
               <div class="row">
           <div class="col-7 text-left">
               <h5 class="callHistory">Call history</h5>
           </div>
           <div class="col-5 text-right">
               <div class="all-calls">
         <select class="callTypeSelect" onChange="callHistory(this.value)">`
         let getAllCallDetailsByAgentIdURL;
         let callTypeHTML = '';
         if(args.length == 0 || args[0] == 'allCalls') {
            getAllCallDetailsByAgentIdURL = localStorage.getItem('endpoint_url') + "/getAllCallDetailsByAgentId";
            callTypeHTML = `<option value="allCalls" selected>All calls</option>
            <option value="missedCalls">Missed calls</option>`
         }
         else{
            getAllCallDetailsByAgentIdURL = localStorage.getItem('endpoint_url') + "/getMissedCallDetailsByAgentId";
            callTypeHTML = `<option value="allCalls">All calls</option>
            <option value="missedCalls" selected>Missed calls</option>`
         }
         let closingHTML =   `</select>
         </div>
         
           </div>
         </div>  
           </div>`
           
           
                console.log('callSid==============', $('#callSid').val())
                $('#callSid').val('')
                console.log('callSid==============', $('#callSid').val())
                $('#callHistoryList').empty();
                $(".createTickets").hide();
                $(".callerOnCall").hide();
                $(".callerDetails").hide();
                
                $(".recentTickets").hide();
                $(".AllTickets").hide();

                let logId = parseInt(localStorage.getItem('loggedInId'));
                let reqObject = {
                    agentId: logId
                 }
                 var headers = {
                    "Content-Type": "application/json"
                 };
                 var options = {
                    headers: headers,
                    body: JSON.stringify(reqObject)
                 };
                
                $('.ajax-loader').css("visibility", "visible");
                client.request.get(getAllCallDetailsByAgentIdURL, options)
                    .then(
                       function (data) {
                            var result = jQuery.parseJSON(data.response);
                            console.log("result====",result)
                           // console.log('data.response===', jQuery.parseJSON(data.response)[0].callSid)
                            let historyHtml = openingHTML + mappedNumberHTML + userMappingIconHTML + headingHTML + callTypeHTML + closingHTML;
                            historyHtml +=`                                                       
                            <div class="history-body">
                            <div class="col-12">
                            `;
            
                            if (result.length != 0) {
                                 
                                historyHtml += callInformation(result);


                                $('.ajax-loader').css("visibility", "hidden");
                                historyHtml += `
                                </div>
                                </div>
                                
                                </div>
                               
                               `;
                                $('#callHistoryList').append(historyHtml);
                                
                            } else {
                                $('.ajax-loader').css("visibility", "hidden");
                                historyHtml += `</div>
                                </div>
                                
                                </div>` +
                                '<div class="card bg-primary text-white bg-info mb-3" >' +
                                '<div class="card-body text-center">No Calls are Available</div>' +
                                '</div><br>'
                                $('#callHistoryList').append(
                                    historyHtml 
                                );
                            }
            
                            
                          
                        },
                        function (error) {
                            if(error) console.log('error in retrieving Call History ='+error);
                            //displayStatus('danger', 'Main:callHistory::CallHistory error')
                        });
                        console.log('ttttttttttttttt')
                        $('#callHistoryList').show();
                }).catch(function(err){
                    console.error('Main:callHistory::Roles error : ', err)
                    displayStatus('danger', 'Main:callHistory::Roles error')
                })
                }).catch(function(err){
                    if(err) console.error('Main:callHistory::mappedNumber(/getMappedNumber API) error : ', err)
                    //displayStatus('danger', 'CTI Error. Refresh the Page')
                })
            }
         

function getTickets(number, callSid, direction) {
    console.log('number=='+number)
    console.log('callSid=======================================', callSid)
    client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/contacts?phone=" + number, {
        headers: {
            "Authorization": '<%= encode(iparam.freshdeskApikey) %>',  
            "Content-Type": "application/json"
        }
    })
        .then(function (contact) {
            var callDetails={};
            /* let requesterId; */
            console.log("contact=====>", jQuery.parseJSON(contact.response));
            callDetails.contact = jQuery.parseJSON(contact.response);
            console.log('callDetails====', callDetails)
            if (jQuery.parseJSON(contact.response).length != 0) {
                /* requesterId = jQuery.parseJSON(contact.response)[0].id;
                console.log('requesterId = '+requesterId)  */  
            }
            else{
                callDetails.phone = number
                callDetails.name = 'Unknown'
               /*  requesterId = 0; */
            }
            $('#callHistoryList').append(`<textarea style="display: none;" id="w3mission" rows="4" cols="50">
        ${JSON.stringify(callDetails)}
        </textarea>` + `<textarea id="callCallSid" style="display: none;">${callSid}</textarea>
        <textarea id="callHistoryCallerDirection" style="display: none;">${direction}</textarea>`)
            newticketCreate(this)
        },
    function (error) {
        console.log(error);
        displayStatus('danger', 'Main:getTickets::GET Contact error')
    })
}


function mappingUsers(){
    console.log("mappingUsers");
    client.interface.trigger("showModal", {
        title: "User Mapping",
        template: "mapping.html",
    }).then(function (data) {
        console.log("app.js modal data===>", data);
    }).catch(function (error) {
        console.log('error', error)
        displayStatus('danger', 'Error in User Mapping Window')
    });    
    
    }

    function makeOutboundCall(toNumber) {
        console.log('toNumber = ', toNumber)
        let logId = parseInt(localStorage.getItem('loggedInId'));
        var headers = {
            "Content-Type": "application/json"
        };
        var options = {
            headers: headers,
            body: JSON.stringify({agentId : logId})
        };
        var url = localStorage.getItem('endpoint_url') + "/getAgentNumberANDCallerIdById";

        client.request.get(url, options)
            .then((mappedNumber) => {
            console.log('mappedNumber=== ', JSON.parse(mappedNumber.response))
           let mappedPhoneNumber = (JSON.parse(mappedNumber.response).length != 0) ? JSON.parse(mappedNumber.response)[0].exotelNumber : '';
           let callerId = (JSON.parse(mappedNumber.response).length != 0) ? JSON.parse(mappedNumber.response)[0].exotelVirutalnumber : '';
           console.log('isOutboundEnable = ', JSON.parse(mappedNumber.response)[0].isOutboundEnable)
           console.log('mappedPhoneNumber & callerId = ', mappedPhoneNumber + ' & ' + callerId)
           let domain;
           if(JSON.parse(mappedNumber.response)[0].isOutboundEnable != 0) {

            client.interface.trigger("show", {id: "softphone"})
            .then(function(openCTI) {
                console.log('openCTI === '+ openCTI)
                
            

            domain = localStorage.getItem('exotelDomain');
            let exotelSid = localStorage.getItem('exotelSid');
            console.log('exotelSid = ', exotelSid)
           console.log('domain = ', domain)
           client.request.post(
            `https://<%= iparam.exotelApikey %>:<%= iparam.exotelApiToken %>${domain}/v1/Accounts/${exotelSid}/Calls/connect.json`,
               {formData : {
                    "From" : mappedPhoneNumber,
                    "To" : toNumber,
                    "CallerId" : callerId,
                    "StatusCallback" : localStorage.getItem('endpoint_url') + '/ans',
                    "StatusCallbackEvents[0]" : "terminal",
                    "StatusCallbackContentType" : "application/json"
               }}
            ).then((outboundCallData) => {
                
                console.log('response = ', JSON.parse(outboundCallData.response).Call)

                let callDetails = {"phone": toNumber}
                client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/contacts?phone=" + toNumber, {
                    headers: {
                        "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                        "Content-Type": "application/json"
                    }
                })
                    .then(function (contact) {
                        console.log('object contact = ', jQuery.parseJSON(contact.response))
                        callDetails.contact = jQuery.parseJSON(contact.response);
                        callDetails.company = '';
                        let pageRender = '';
                        if(jQuery.parseJSON(contact.response).length !=0 ) {
                            let contactResponse = jQuery.parseJSON(contact.response)[0];
                            callDetails.name = contactResponse.name;
                            postContactDetails(JSON.parse(outboundCallData.response).Call.Sid, contactResponse.id, contactResponse.name);
                            if(contactResponse.company_id != null) {
                                client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/companies/" + contactResponse.company_id, {
                                    headers: {
                                        "Authorization": '<%= encode(iparam.freshdeskApikey) %>',
                                        "Content-Type": "application/json"
                                    }
                                }).then(function (company) {
                                    console.log('JSON.parse(company.response).name===', JSON.parse(company.response).name)
                                    callDetails.company = JSON.parse(company.response).name
                                }).catch(error => {
                                    console.error('Error in Company Details : ', error)
                                    displayStatus('danger', 'Error in Company Details')
                                })
                            }
                            pageRender = knownScreenPop(callDetails.name, callDetails.phone, callDetails.company, JSON.parse(outboundCallData.response).Call.Direction, callDetails, JSON.parse(outboundCallData.response).Call.Sid);
                        }
                        else {
                            callDetails.name = 'Unknown'
                            pageRender = unknownScreenPop(callDetails.name, callDetails.phone, JSON.parse(outboundCallData.response).Call.Direction, callDetails, JSON.parse(outboundCallData.response).Call.Sid);
                        }
                        screenPop(pageRender)
                    }, function(error) {
                        console.error('Main:makeOutboundCall:: GET Contact API error', error)
                        displayStatus('danger', 'Number is not available in Contact')
                    })

                let url = localStorage.getItem('endpoint_url') + "/postOutboundCall";
                let headers = {
                    "Content-Type": "application/json"
                }
                var options = {
                    headers: headers,
                    body: JSON.stringify({"call" : JSON.parse(outboundCallData.response).Call, "from" : mappedPhoneNumber, "to" : toNumber})
                };
                client.request.post(url, options)
                .then((postCallData)=> console.log('postCallData = ', postCallData))
                .catch(error => {
                    console.error('Error in PostCall Data : ', error)
                    displayStatus('danger', 'Error in Storing the call details')
                })
            }).catch((error) => {
                console.log('error = ', JSON.parse(error.response).RestException)
                console.log('error = ', JSON.parse(error.response).RestException.Message)
                console.log('error = ', JSON.parse(error.response).RestException.Status)
                displayStatus('danger', 'Cannot make Outgoing Call')
            })
        }).catch(function(error) {
            console.log('error:', error)
            });
        
    }
    else {
        displayStatus('danger', 'Not allowed to make outbound call');
    }
        },function (error) {
            console.log('Main:makeOutboundCall:: /getAgentNumberANDCallerIdById API error ', error);
            displayStatus('danger', 'Agent does not have Mobile Number. Contact Admin for support')
        }
        ) 
    }

    function screenPop(pageRender) {
        $('.recentTickets').show();
        $(".Reply").hide();
        $(".ModalPopup").hide();
        $(".showContacts").hide();
        $('#callHistoryList').hide();
        $(".callerDetails").show();
        $(".callerDetails").empty();
        pageRender += footerHTML;
        $(".callerDetails").append(pageRender);
        
    }

    function addCallDirectionImage(callDirection, callState, contactName, callFrom, callTo) {
        let callDirectionHtml = '';
        if(callDirection == "incoming" && (callState == "pop" || callState == "answered")){
            callDirectionHtml += `
            <div class="icon-sec bg-light-green text-center">
            <svg width="20" height="20" class="incoming" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 30 30" style="enable-background:new 0 0 30 30;" xml:space="preserve">
            <style type="text/css">
                .incoming .st0{fill:#00A886;}
            </style>
            <path class="st0" d="M4.3,27H19c0.7,0,1.3-0.6,1.3-1.3c0-0.7-0.6-1.3-1.3-1.3H7.6L26.6,5.3c0.5-0.5,0.5-1.4,0-1.9  C26.3,3.1,26,3,25.7,3c-0.3,0-0.7,0.1-0.9,0.4L5.7,22.4V11c0-0.7-0.6-1.3-1.3-1.3C3.6,9.7,3,10.3,3,11v14.7C3,26.4,3.6,27,4.3,27z"/>
            </svg></div></div>
            <div class="col-5">
            <div class="name">
            <p>${contactName}</p>
            <span class="w100">${callFrom}</span>
            </div>
            </div>
            `;
        }
        else if(callDirection == "incoming" && callState == "missed"){
            callDirectionHtml += `<div class="icon-sec bg-light-pink bg-light-blue text-center">
            <svg class="missed" width="20" height="20" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 30 30" style="enable-background:new 0 0 30 30;" xml:space="preserve">
            <style type="text/css">
                .missed .st0{fill:#E43538;stroke:#E43538;stroke-miterlimit:10;}
            </style>
            <path class="st0" d="M28.4,11.8c-0.3-0.4-0.9-0.4-1.2-0.1l-9.9,8c-1.4,1.1-3.6,0.9-4.8-0.5l-7-8.7l7.6,0.8c0.5,0.1,0.9-0.3,1-0.8  c0.1-0.5-0.3-0.9-0.8-1L3.5,8.4C3,8.3,2.6,8.7,2.5,9.1l-1.1,9.7c-0.1,0.5,0.3,0.9,0.8,1c0.5,0.1,0.9-0.3,1-0.8l0.8-7.6l7,8.7  c0.9,1.1,2.1,1.7,3.5,1.9c1.4,0.2,2.7-0.2,3.8-1.1l9.9-8C28.6,12.7,28.7,12.2,28.4,11.8z"/>
            </svg></div></div>
            <div class="col-5">
            <div class="name">
            <p>${contactName}</p>
            <span class="w100">${callFrom}</span>
            </div>
            </div>
            `;
        }
        else {  //direction = 'outbound-dial' or 'outbound-api'
        callDirectionHtml += `<div class="icon-sec bg-light-blue text-center">
            <svg class="outgoing" width="20" height="20" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 30 30" style="enable-background:new 0 0 30 30;" xml:space="preserve">
            <style type="text/css">
                .outgoing .st0{fill:#2c5cc5;}
            </style>
            <path class="st0" d="M25.7,3H11c-0.7,0-1.3,0.6-1.3,1.3s0.6,1.3,1.3,1.3h11.4L3.4,24.7c-0.5,0.5-0.5,1.4,0,1.9C3.7,26.9,4,27,4.3,27  c0.3,0,0.7-0.1,0.9-0.4L24.3,7.6V19c0,0.7,0.6,1.3,1.3,1.3c0.7,0,1.3-0.6,1.3-1.3V4.3C27,3.6,26.4,3,25.7,3z"/>
            </svg></div></div>
            <div class="col-5">
            <div class="name">
            <p>${contactName}<p>
            <span class="w100">${callTo}</</span>
            </div>
            </div>
           `
        }
        return callDirectionHtml;
    }

    function callInformation(response) {
        let callInfoHTML = '';
        for(let res of response){
            console.log('res.callDirection == ', res.callDirection)
             let number = res.callDirection === 'incoming' ? res.callFrom : res.callTo;
             
             console.log('number===', number);
             console.log('res.duration===', res.duration)
             console.log('contactName = ', res.contactName)
             let contactName = res.contactName == null ? 'Unknown' : res.contactName;
             let duration = res.duration == null ? 0 : res.duration;
             console.log('duration = '+ duration)
             
             
             let durationFormat = formatCallDuration(duration);

             callInfoHTML +=  
                                                
             `<div class="list-sec pt-xl-3 pl-xl-3 pr-xl-3 pb-xl-3 row align-items-center">
             <div class="row align-items-center">
             <div class="col-2 pdrgt0">`;
             console.log('res.callState', res.callState)
             
             callInfoHTML += addCallDirectionImage(res.callDirection, res.callState, contactName, res.callFrom, res.callTo);
             
             callInfoHTML +=`
             <div class="col-5 text-right pdlft0">
             <div class="time">
             
             <span class="seconds w100">${durationFormat}</span>
             <span class="hours w100" style="font-size:11px !important">${res.startTime}</span>
             </div>
            
             <div class="call-over-action">
             <button class="btn btn-round-white" onClick="getTickets('${number}', '${res.callSid}', '${res.callDirection}')">

             <span style="font-size: 10px;">Add Note<span>

             </button>
             <button class="btn btn-round-green" data-toggle="tooltip" title="make call" onClick="makeOutboundCall('${number}')"><svg class="phone" width="20" height="20" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 30 30" style="enable-background:new 0 0 30 30;" xml:space="preserve">
             <style type="text/css">
             .phone .st0{fill-rule:evenodd;clip-rule:evenodd;fill:#FFFFFF;}
             </style>
             <path class="st0" d="M12.4,17.7c-1.2-1.4-2.3-3.1-3.2-5.2c-0.1-0.2-0.1-0.1,0-0.3l2.5-2.5c0,0,0,0,0-0.1L10,3  C9.9,2.7,7.5,2.3,7.1,2.5C0.5,6,3.5,14.5,9.1,20.6c5.4,6.3,13.5,10.2,17.7,4.1c0.3-0.4,0.2-2.8-0.1-2.9l-6.4-2.5c-0.1,0-0.1,0-0.1,0  l-2.8,2.2c-0.1,0.1-0.1,0.1-0.3,0C15.2,20.3,13.7,19,12.4,17.7"/>
             </svg></button>
             </div>


             </div>


             </div>
             </div>`;
         
         }
         return callInfoHTML;
    }

function formatCallDuration(duration) {
    let hour = Math.floor(parseInt(duration)/60/60) > 9 ? "" + Math.floor(parseInt(duration)/60/60) : '0' + Math.floor(parseInt(duration)/60/60)
    let minute = Math.floor(parseInt(duration)/60) > 9 ? "" + Math.floor(parseInt(duration)/60) : '0' + Math.floor(parseInt(duration)/60)
    let second =  parseInt(duration)%60 > 9 ? "" + parseInt(duration)%60 : '0' + parseInt(duration)%60
    return hour + ':' + minute +':'+ second;
}