
 var MIDDLEWARE_URL = "https://318edd4d.ngrok.io";

 var sta = 0,mappedUserDetail;
 var elements_per_page = 5;
 var limit = elements_per_page;
 var max_size,mappedUserHtml = ``;
 
 
 $(document).ready(function () {
 
 
     app.initialized()
     .then(function (_client) {
         window.body = $('body');
         window.client = _client;
         $('#newMappingForm').hide();
         $('.maplistpage').hide();
         $('#newMapping').show()
         $('#editMappingForm').hide();
         $(".ispagination").hide();
 $(".newMappingForm").hide();
         getMappingDetails();
 
         /*----------- pagination for data table --------------- */
         $('#userNext').click(function(){
 
             var next = limit;
             if(max_size>next) {
                 limit = limit+elements_per_page;
                 mappedUserHtml =``;
                 console.log(next +' -next- '+limit);
                 getpaginationagents(next,limit);
             }else{
                 $("a.page-link.userNext").css({cursor:"not-allowed"});
                 $("a.page-link.userPrev").css({cursor:"pointer"});
             }
         });
         $('#userPrev').click(function(){
             var pre = limit-(2*elements_per_page);
             if(pre>=0) {
                 limit = limit-elements_per_page;
                 console.log(pre +' -pre- '+limit);
                 mappedUserHtml =``;
                 getpaginationagents(pre,limit); 
             }else{
                 $("a.page-link.userPrev").css({cursor:"not-allowed"});
                 $("a.page-link.userNext").css({cursor:"pointer"});
             }
         });

         
         /* ------------------- get agents for to make ui select dropdown ------------------ */
 
         $('#newMapping').click(function() {


let htmlObj=`

<div class="container">
<div class="row">
  <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
    <div class="card card-signin my-5">
      <div class="card-body">
        <div class="successmessage" id="successmessage" style="display: none;">
          <p></p>
        </div>
        <div class="errormessage" id="errormessage" style="display: none;">
          <p></p>
        </div>

        <h2 class="card-title text-center">New Mapping User</h2>
       <!-- <div class="form-label-group">
          <label for="inputEmail" class="formlabell">Exotel AccountSid<span style="color:red">*</span></label>
          <input type="email" id="exotelSid" class="form-control" placeholder="" >
		</div> -->
		
		<div class="form-label-group">
        <label for="inputEmail" class="formlabell">Caller Id<span style="color:red">*</span></label>
        <input type="text" id="exotelVirutalnumber" class="form-control" placeholder="" required>
      </div>

        <div class="form-label-group">
         <label for="inputPassword" class="formlabell">Mobile Number<span style="color:red">*</span></label>
         <input type="text" id="exotelNumber" class="form-control" placeholder="" >
       </div>

       <div class="form-label-group">
        <label for="inputEmail" class="formlabell">Freshdesk User<span style="color:red">*</span></label>
        <select id="freshdeskAgentList" name="freshdeskAgentList" class="form-control"  >
        </select>
        </div>
        <div>
          <label for="enableOutbound" class="formlabell">Enable Outbound</label>  
          <input type="checkbox" id="enableOutbound" name="enableOutbound" checked>
        </div>
        <br><br>
      <button class="btn btn-lg btn-block text-uppercase saveMapping" onClick="saveMappingDetails()" id="saveMapping" type="submit">Save</button>
      <button type="button" class="btn btn-outline-dark" onClick="backAction()" id="backarrow">Back</button>

    </div>
  </div>
</div>
</div>
</div>

`
$(".newMappingForm").append(htmlObj);

             clearForm()
             getAllAgents("createuser")
         });
 
 
 
         function clearForm() {
             $("#freshdeskAgentList").val("");
             $("#exotelNumber").val("");
             $("#exotelVirutalnumber").val("");
         }
         
         /* ------------------- new mapping for agent ------------------ */
 
         $('#saveMapping').click(() => saveMappingDetails())
 
        
         /*----------- delete mapped user ----------------*/
 
         $("#mytable1 tbody").on('click','.deletemap', function(e){
             console.log('e', e)
             delete_id = $(this).attr("data-userid");
             console.log("The data-id of clicked user is: " + delete_id);
             var headers = { 
                 "Content-Type": "application/json"
             };
             let reqObject = {
                 agentId: delete_id
             }
 
             var options = {
                 headers: headers,
                 body: JSON.stringify(reqObject)
             };
             var url = localStorage.getItem('endpoint_url') + "/deleteMap";
 
             client.request.get(url, options)
             .then((data) => {
 
                 console.log('delete map result==========>'+data.response);
                 deleted_response = JSON.parse(data.response);
                 if(deleted_response.affectedRows == 1){
                     $('#deletemessage p').html('Mapped User Removed Successfully.');
                     $('#deletemessage').show();
                     setTimeout(function() {
                         $('#deletemessage').hide();
                         mappedUserHtml=``;
                         $('#mappedUsers').empty();
                         getMappingDetails();
                     }, 3000);
                     return false;
                 }else{
                     $('#deleteerror p').html('Error occured in user mapping ');
                     $('#deleteerror').show();
                     setTimeout(function() {
                         $('#deleteerror').hide();
                     }, 3000);
                 }
             });
         });
 
         /*---------------- get agent information in edit page ---------------------*/
    
 
         /*------------------- edit user mapping page creation -----------------------------*/
        
 
     },
     function (error) {
         /* If unsuccessful */
         showError('App Initialization failed.');
         console.info(error);
     });
    

 });
 
 /*------------------------------ user mapping edit ----------------------- */
 function editinguser(editId){
     console.log("editt");
     
     editMappingDetails(editId);
 }

 function editMappingDetails(editId) {
     console.log(editId,"editId");
        let exotelSid = localStorage.getItem('exotelSid');
        console.log('exotelSid = ', exotelSid)
     var freshdeskAgentId = $("#edit_freshdeskAgentList").val();
     
     var exotelNumber = $("#edit_exotelNumber").val();
     var exotelVirutalnumber = $("#edit_exotelVirutalnumber").val();
     var freshdeskAgent= $("#edit_freshdeskAgentList option:selected").text();
     let isOutboundEnable = document.getElementById("enableOutboundEdit").checked ? 1 : 0;
     if(freshdeskAgentId != "" && exotelSid != "" && exotelNumber != "" && exotelVirutalnumber != ""){
         let mappingObject = {
             exotelSid: exotelSid,
             freshdeskAgent: freshdeskAgent,
             freshdeskAgentId: freshdeskAgentId,
             exotelNumber:exotelNumber,
             exotelVirutalnumber:exotelVirutalnumber,
             isOutboundEnable : isOutboundEnable
         }
         console.log('mappingObject', mappingObject);
         var headers = { 
             "Content-Type": "application/json"
         };
         var options = {
             headers: headers,
             body: JSON.stringify(mappingObject)
         };
         var url = localStorage.getItem('endpoint_url') + "/editMap/"+editId;
         client.request.post(url, options)
         .then((data) => {
             console.log('edit mapped data==========>'+data.response);
             edited_response = JSON.parse(data.response);
             if(edited_response.affectedRows == 1){
                 $('#editsuccessmessage p').html('Record has been edited successfully');
                 $('#editsuccessmessage').show();
                 setTimeout(function() {
                     $('#editsuccessmessage').hide();
                     mappedUserHtml=``;
                     $('#mappedUsers').empty();
                     getMappingDetails();
                 }, 3000);
 
                 return false;
             }
         })
     }else {
         $('#editerrormessage p').html('Please Fill All Mapping Fields.');
         $('#editerrormessage').show();
         setTimeout(function() {
             $('#editerrormessage').hide();
         }, 3000);
     }
 }
 function editbackAction(){
     mappedUserHtml=``;
	 $('#mappedUsers').empty();
     getMappingDetails();   
 }  
 /*----------- check pagination and initial table loading start --------------- */
 
 function check_pagination(total_element,limit){
     console.log("total_element======>",total_element);
         console.log("limit======>",limit);
 
     if(total_element <= limit ){
         $(".ispagination").hide();
     }else if(total_element > limit){
             console.log("total_element======>showed");
 
         $(".ispagination").show();
 
     }
 }
 
 
 function getpaginationagents(sta,limit){
     
     mappedUserHtml=``;
     for (var i = sta; i < limit; i++) {
 
         if(mappedUserDetail[i] != undefined){
            console.log('appedUserDetail',mappedUserDetail[i].isOutboundEnable)
             mappedUserHtml += `<tr>
             </td>
             <!-- <td> <span class="mappedUser${i}" id="mappedUser${i}">${mappedUserDetail[i].accountSid}</span> </td> -->
             <td><span class="fdkagent${i}" id="fdkagent${i}">${mappedUserDetail[i].exotelVirutalnumber}</span> &ensp;</td>
             <td><span>${mappedUserDetail[i].exotelNumber}</span></td>
             <td><span>${mappedUserDetail[i].agentName}(${mappedUserDetail[i].agentId})</span></td>
             <td>`;
             
             if(mappedUserDetail[i].isOutboundEnable == 0) {
                mappedUserHtml += `<input type="checkbox" id="isOutboundEnable" name="isOutboundEnable" disabled>`
             }
             else {
                mappedUserHtml += `<input type="checkbox" id="isOutboundEnable" name="isOutboundEnable" checked disabled>`
             }
             mappedUserHtml += `</td><td class="agent">
<button data-userid="${mappedUserDetail[i].id}"  data-toggle="tooltip" data-placement="top" title="Edit" style="min-width:1%" class="btn edit btn-info btn-sm editmap" id="edit"><i class="fa fa-pencil"></i></button>&nbsp;
             <button data-userid="${mappedUserDetail[i].id}" data-toggle="tooltip" data-placement="top" title="Delete" style="min-width:1%" class="btn dlt btn-danger btn-sm deletemap" data-locationid="'+locationResultsObj[i].id+'" data-dismiss="modal" id="dlt"><i class="fa fa-trash-o"></i></button>
             </td>`

         }
     }                  
     mappedUserHtml += `</tr>`;
     $('#mappedUsers').empty()
	 $('#mappedUsers').append(mappedUserHtml);
	 $('.maplistpage').show();
     $('#mappedUsers').show();
 }
 /*----------- check pagination and initial table loading end --------------- */
 
 /*-------------------- get All mapped users ---------------------------- */
 
 function getMappingDetails() {
    let accountSid = localStorage.getItem('exotelSid');
    var headers = { 
        "Content-Type": "application/json"
    };
    var options = {
        headers: headers,
        body: JSON.stringify({'accountSid' : accountSid})
    };
 client.request.get(localStorage.getItem('endpoint_url') + "/getMap", options) 
     .then(function (users) {
         $('#newMappingForm').hide()
         $('#editMappingForm').hide()
         $('#saveMapping').hide();
         $('#newMapping').show()
         $('#userMapPage').show()
 
         let mappedUserHtml = ``;

         mappedUserDetail = JSON.parse(users.response);
         console.log("mappedUserDetail===>",mappedUserDetail);
         if(mappedUserDetail.length != 0) {
             max_size=mappedUserDetail.length;
                 console.log("max_size======>",max_size);
             sta=0;limit=5;
             check_pagination(max_size,limit);
             getpaginationagents(sta,limit);
 
         }else if(mappedUserDetail.length == 0){
             console.log("*********************************8");
             mappedUserHtml = `<tr><td colspan="5"><p style="text-align: center;font-size:15px">No data is available </p></td></tr>`;
             $('.maplistpage').show();
             $('#mappedUsers').empty()
             .append(mappedUserHtml);
             $('#mappedUsers').show()
 
         }
     })
 }
 function saveMappingDetails() {
    $('#mappedUsers').hide();
        let exotelSid = localStorage.getItem('exotelSid');
        console.log('exotelSid = ', exotelSid)
    var freshdeskAgentId = $("#freshdeskAgentList").val();
    
    var exotelNumber = $("#exotelNumber").val();
    var exotelVirutalnumber = $("#exotelVirutalnumber").val();
    var freshdeskAgent= $("#freshdeskAgentList option:selected").text();
    let isOutboundEnable = document.getElementById("enableOutbound").checked ? 1 : 0;
    if(freshdeskAgentId != "" && exotelSid != "" && exotelNumber != "" && exotelVirutalnumber != ""){
        let mappingObject = {
            exotelSid: exotelSid,
            freshdeskAgent: freshdeskAgent,
            freshdeskAgentId: freshdeskAgentId,
            exotelNumber:exotelNumber,
            exotelVirutalnumber:exotelVirutalnumber,
            isOutboundEnable : isOutboundEnable
        }
        console.log('mappingObject', mappingObject);
        var headers = { 
            "Content-Type": "application/json"
        };
        var options = {
            headers: headers,
            body: JSON.stringify(mappingObject)
        };
        var url = localStorage.getItem('endpoint_url') + "/saveMap";
        client.request.post(url, options)
        .then((data) => {
            console.log('mapped data==========>'+data.response)
            $('#successmessage p').html('Record has been saved successfully.');
            $('#successmessage').show();
            setTimeout(function() {
                $('#successmessage').hide();
            }, 3000);
            mappedUserHtml=``;
            $('#mappedUsers').empty();
            getMappingDetails();
            return false;

        })
    }else {
        $('#errormessage p').html('Please Fill All Mapping Fields.');
        $('#errormessage').show();
        setTimeout(function() {
            $('#errormessage').hide();
        }, 3000);
    }
}
 
         /* ------------------- back action ------------------ */
         function backAction(){     
                //  mappedUserHtml=``;
		//  $('#mappedUsers').empty();
		$(".newMappingForm").empty();
         getMappingDetails();
        // $("#listHtml").show();

     }

    //function editmap(id){
          $("#mytable1 tbody").on('click','.editmap', function(e){
              console.log('e', e)
             edit_id = $(this).attr("data-userid");
             console.log("The data-id of clicked user is: " + edit_id);
             var headers = { 
                 "Content-Type": "application/json"
             };
             let reqObject = {
                 id: edit_id
             }
 
             var options = {
                 headers: headers,
                 body: JSON.stringify(reqObject)
             };
             var url = localStorage.getItem('endpoint_url') + "/editUserMapInfo";
 
             client.request.get(url, options)
             .then((data) => {
                             //console.log('edit map result==========>'+data.response);
                             current_user = JSON.parse(data.response);
                             if(current_user){
                                 editMappingForm(current_user);
                             }
                             return false;
 
                         });
         })
         function editMappingForm(current_user){
			console.log('current_user', current_user)
            getAllAgents("edituser");
            $('#newMappingForm').hide();
            $('#newMapping').hide();
            $('.maplistpage').hide();
            $('#saveMapping').hide();
            $('.userMapPage').hide();
            $('#editMappingForm').show();
            $('#editMappingForm').empty();
            var editAgentHtml=``;
            editAgentHtml =`<div class="container">
            <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
            <div class="card card-signin my-5">
            <div class="card-body">
            <div class="successmessage" id="editsuccessmessage" style="display: none;">
            <p></p>
            </div>
            <div class="errormessage" id="editerrormessage" style="display: none;">
            <p></p>
            </div>

            <h2 class="card-title text-center">Edit Mapping</h2>
            <!-- <div class="form-label-group">
            <label for="inputEmail" class="formlabell">Exotel Sid<span style="color:red">*</span></label>
            <input type="text" id="edit_exotelSid" value="${current_user[0].accountSid}" class="form-control" placeholder="" >
			</div> -->
			<div class="form-label-group">
            <label for="inputEmail" class="formlabell">Caller Id<span style="color:red">*</span></label>
            <input type="text" id="edit_exotelVirutalnumber" value="${current_user[0].exotelVirutalnumber}" class="form-control" placeholder="" required>
            </div>

            <div class="form-label-group">
            <label for="inputPassword" class="formlabell">Mobile Number<span style="color:red">*</span></label>
            <input type="text" id="edit_exotelNumber" value="${current_user[0].exotelNumber}" class="form-control" placeholder="" >
            </div>

            <div class="form-label-group">
            <label for="inputEmail" class="formlabell">Freshdesk User<span style="color:red">*</span></label>
            <select id="edit_freshdeskAgentList" name="edit_freshdeskAgentList" class="form-control">
            <option id="selectedEdit" value="${current_user[0].agentId}">${current_user[0].agentName}</option>
            </select>
            </div>
            <div>
            <label for="enableOutboundEdit" class="formlabell">Enable Outbound</label>  
            `
            editAgentHtml += current_user[0].isOutboundEnable == 0 ?
            `
            <input type="checkbox" id="enableOutboundEdit" name="enableOutboundEdit">
            ` :
            `
            <input type="checkbox" id="enableOutboundEdit" name="enableOutboundEdit" checked>
            `
            editAgentHtml += `</div><br><br>
            <button class="btn btn-lg btn-block text-uppercase"  onClick="editinguser(${current_user[0].id})" id="editMapping">Save</button>

            <button type="button" class="btn btn-outline-dark editbackArrow" onClick="editbackAction()" id="edit_backarrow">Back</button>

            </div>
            </div>
            </div>
            </div>
            </div>`;            
            $('#editMappingForm').append(editAgentHtml);

		}
		

		function getAllAgents(action) {
			if(action == "createuser"){
				$('#newMappingForm').show();
				$('#editMappingForm').hide();
				$('#saveMapping').show();
				$('#editMapping').hide();
				$(".ispagination").hide();


			}else if(action == "edituser"){
				$('#editMappingForm').show();
				$('#editMapping').show();
				$('#saveMapping').hide();
				$('#newMappingForm').hide();
				$(".ispagination").hide();

			}
			$('#newMapping').hide();
			$('.maplistpage').hide();
			$('.userMapPage').hide();
			
			client.request.get("<%= iparam.freshdeskDomain %>" + "/api/v2/agents", {
				headers: {
					"Authorization": '<%= encode(iparam.freshdeskApikey) %>',
					"Content-Type": "application/json"
				}
			})
			.then((agents) =>{
				let agentList = JSON.parse(agents.response)
				console.log('agentList==================>', agentList)
				var agentListHtml = '<option value="">Select the agent</option>';
				$.each(agentList, function (index, agentList) {
					agentListHtml += `<option value="${agentList.id}" >${agentList.contact.name} </option>`;
				})
				if(action == "createuser"){
					$('#freshdeskAgentList').empty();
					$('#freshdeskAgentList').append(agentListHtml);
				}else if(action == "edituser"){
					let val = $('#edit_freshdeskAgentList').val();
					$('#edit_freshdeskAgentList').empty();
					$('#edit_freshdeskAgentList').append(agentListHtml);
					$(`#edit_freshdeskAgentList option[value=${val}]`).attr('selected','selected')
					
				}
			})
		}